<html>
     <h1>Đặt vé thành công</h1> 
    <a href="">Quay lại trang chủ</a>
</html>