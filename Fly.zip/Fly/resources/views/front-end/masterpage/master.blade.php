
@include('front-end.masterpage.header')

@yield('content');
 
 @include('front-end.masterpage.footer')