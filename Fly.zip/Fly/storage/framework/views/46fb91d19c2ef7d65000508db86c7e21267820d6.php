<?php /* D:\ProgramD\htdocs\Framew\lar2\resources\views/front-end/airport.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <main> 
       
       <div class="container">
                <section>
                    <h2> Danh Sách Các Sân Bay</h2>
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="row alert" >
                                            <div class="col-sm-3">
                                                <label class="control-label"> Tên Sân Bay</label>                                       
                                            </div>
                                            <div class="col-sm-3">
                                                <label class="control-label">Mã Sân Bay</label>
                                            </div>
                                            <div class="col-sm-3">
                                                <label class="control-label">Tên Tỉnh</label>
                                        
                                            </div>
                                         
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php $__currentLoopData = $sql; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article>
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-12">
                                 
                                        <h4><strong><a href="#"> <?php echo e($row->airport_id); ?>

                                        </a></strong></h4>
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <label class="control-label"><?php echo e($row->airport_name); ?></label>
                                           
                                                <div><big class="time"></big></div>
                                                <div><span class="place"> </span></div>
                                            </div>
                                            <div class="col-sm-3">
                                                <label class="control-label"><?php echo e($row->airport_code); ?></label>
                                                <div><big class="time"></big></div>

                                
                                                <div><span class="place"></span></div>
                                            </div>
                                            <div class="col-sm-3">
                                                <label class="control-label"><?php echo e($row->province_name); ?></label>
                                                <div><big class="time">
                                        
                                                </big></div>
                                               
                                            </div>
                                         
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-center">
                        <ul class="pagination">
                            <li><a href="#">&laquo;</a></li>
                            <li><a href="#">&lsaquo;</a></li>
                            <li class="active"><a href="#">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#">4</a></li>
                            <li><a href="#">&rsaquo;</a></li>
                            <li><a href="#">&raquo;</a></li>
                        </ul>
                    </div>
                </section>
            </div>
           
    </main>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.masterpage.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>